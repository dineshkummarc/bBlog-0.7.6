
  <h3>Upgrade</h3>
  
<p>to run the upgrade, <a href="install/standalone.upgrade.bblog07.php">click here</a></p>

</body>
</html>

<?php 
//make sure the installer stops here
die(); ?>