<?php
// function.sapi_test.php 
//
// Written by Elie BLETON <lordwo__at__sourceforge__dot__net>
//
// This function is only intented to provide test routines for the SettingsAPI.
// It have no other purposes than making something crash if possible, to pinpoint bugs.
//
// DO NOT USE IT IF YOU DO NOT KNOW WHAT YOU ARE DOING.
// Well, using it won't harm if you're curious. If not, you're just wasting your time.
//

/*
** bBlog Weblog http://www.bblog.com/
** Copyright (C) 2003  Eaden McKee <email@eadz.co.nz>
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

?>