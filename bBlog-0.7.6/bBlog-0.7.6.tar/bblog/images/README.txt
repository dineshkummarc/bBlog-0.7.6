These buttons stolen from "Steal These Buttons" : http://gtmcknight.com/buttons/index.php

In the future there will be an admin interface for them :)
